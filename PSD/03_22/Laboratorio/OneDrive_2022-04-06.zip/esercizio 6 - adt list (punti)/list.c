#include <stdio.h>
#include <stdlib.h>
#include "item.h" 
#include "list.h"


struct node {
     item value;
     struct node *next;
};


list newList(void)
{

}

int emptyList(list l)
{
}


list consList(item val, list l)
{
}

list tailList(list l)
{
}

item getFirst (list l)
{
    
}

int sizeList (list l)
{
     
}

int posItem (list l, item val)
{
      
}

item getItem (list l, int pos)
{
    
}

list reverseList (list l)
{
    
}

void outputList (list l)
{

}
