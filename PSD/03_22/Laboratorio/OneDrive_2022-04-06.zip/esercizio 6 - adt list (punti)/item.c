#include <stdio.h>
#include <math.h>
#include "item.h"

struct puntoitem{
       float x;
       float y;
};

int eq(item a, item b){
   
}

item creaItem(float a, float o){
    
}

item input_item(){
    
}

float distanza(item p1, item p2){
      
}
      

void output_item(item it){
     
}
